@echo off
rem Unity Boost - change translation language in an installed game. Runs install.ps1 -ChangeLang.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0install.ps1" -ChangeLang
if errorlevel 1 pause
